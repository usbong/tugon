<b>なにかをして</b><br/>
nanika wo shite,<br/>
--> Kung anong bagay gawin,<br/>
<b>うまく　行ってると、うれしい。</b><br/>
umaku itteru to ureshii.<br/>
--> maiging umuusad, maligaya.<br/>
<b>うまく　行ってないと、うれしくない。</b><br/>
umaku ittenai to ureshikunai.<br/>
--> hindi maiging umuusad, hindi maligaya.<br/>
<br/>
<b>だとしたら、うまく　行ってること　だけに</b><br/>
datoshitara, umaku itteru koto dakeni <br/>
--> Kung gawin ang ganoon, ang maiging umuusad na bagay lamang<br/>
<b>集中して、永遠に　うれしい</b></b><br/>
shuuchuu shite, eien ni ureshii <br/>
--> ang tutukan, mahaba't malayo [ang katapusan] (eternity) na ligaya<br/>
<b>ということ　かな？</b><br/>
to iu koto kana?<br/>
--> ang sinasabing bagay kaya ito?<br/>
<br/>
<b>意味が　わかれば、最初　うまく　行ってないが、</b><br/>
imi ga wakareba, saisho umaku ittenaiga,<br/>
--> Kapag nauunawaan ang saysay, sa simula, hindi man maiging umuusad,<br/>
<b>うまく　行けるまで　がんばらなくては　ならない。</b><br/>
umaku ikeru made gambaranakuteha naranai.<br/>
--> hanggang maiging makausad, ang hindi gawin nang lubos ang magagawa, hindi magiging ganoon.<br/>
<br/>
<b>うれしいことも　うれしくないことも　なかったら、</b><br/>
ureshiikoto mo ureshikunai koto mo nakattara,<br/>
--> Kapag ang ligaya pati ang hindi ligaya rin wala<br/>
<b>やってみたら、飽きちゃうと　わかった。</b><br/>
yatte mitara, akichau to wakatta.<br/>
--> Subukang gawin, magsasawa, ito naunawaan ko.<br/>
<br/>
<b>コンビにの　ハンバーグ入り弁当　だけを</b><br/>
kombini no hamba-gu iri bentou dake wo <br/>
--> Ang may hamburger meat na bentou (pagkaing ibinasta) ng tindahan lamang<br/>
<b>二週間ほど　食べて、飽きちゃったから。</b><br/>
nishuukan hodo tabete, akichattakara.<br/>
--> dalawang linggo ang inabot sa pagkain, nagsawa kasi ako.<br/>
<br/>
<b>事務所のビルで　売ってるもの　より安くて、</b><br/>
jimusho no biru de utteru mono yori yasukute,<br/>
--> Sa gusali ng opisina, kaysa sa ibinibentang pagkain, higit na mura,<br/>
<b>腹が　空くことも　なかったし。</b><br/>
hara ga suku koto mo nakatta shi.<br/>
--> ang tiyan, hindi rin naman nawalan ng laman.<br/>
<br/>
<b>やる意味が　わかるが、感情なし　だとしたら、</b><br/>
yaru imi ga wakaruga, kanjou nashi datoshitara,<br/>
--> Bagama't nauunawaan ang saysay sa paggawa, kung walang pakiramdam,<br/>
<b>飽きちゃって、他のモノか　コトにする　となる</b><br/>
akichatte, hoka no mono ka koto ni suru to naru.<br/>
--> magsasawa, sa ibang bagay o gawain ilalaan, magiging ganoon.<br/>
<br/>
<b>われわれ　人間、　みんな　そう　であれば、うれしいね。</b><br/>
wareware ningen, minna sou de areba, ureshii ne.<br/>
--> Tayong tao, kapag ganoon naman tayo, maligaya, 'di ba?<br/>
